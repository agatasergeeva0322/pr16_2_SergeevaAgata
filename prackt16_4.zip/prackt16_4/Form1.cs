﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prackt16_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Country> countries = new List<Country>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text.Replace(" ", ""), out int rez))
            {
                long n = long.Parse(textBox1.Text.Replace(" ", ""));
                if (n >0 )
                {
                    var sortCountry = countries.Where(c => c.Population > n)
                                           .OrderBy(c => c.NameCountry.Length)
                                           .ToList();

                    listBox2.Items.Clear();
                    foreach (Country country in sortCountry)
                    {
                        listBox2.Items.Add(country.NameCountry + " " + country.Population);
                    }
                }
                else MessageBox.Show("Численность населения не может быть отрицательной или нулевой!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Формат ввода был некорректным!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("jupiter.jpg");
            if (File.Exists("countries.txt"))
            {
                //Занесение в коллекцию данных из файла
                string[] lines = File.ReadAllLines("countries.txt");
                if (lines.Length != 1)
                {
                    foreach (string line in lines)
                    {
                        char digit = line.First(c => char.IsDigit(c));
                        int ind = line.IndexOf(digit);
                        string name = line.Substring(0,ind);
                        string popul = line.Substring(ind);
                        long population = long.Parse(popul.Replace(" ", ""));
                        countries.Add(new Country(name, population));
                    }

                    //Сортировка стран по длине строки
                    var sortCountries = countries.OrderBy(c => c.NameCountry.Length);

                    //Вывод отсортированных стран
                    listBox1.Items.Clear();
                    foreach (Country country in sortCountries)
                    {
                        listBox1.Items.Add(country.NameCountry + " " + country.Population);
                    }
                }
                else MessageBox.Show("Файл с данными пустой!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("Файл с данными не найден!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }
}

