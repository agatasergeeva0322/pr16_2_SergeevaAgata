﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prackt16_4
{
    internal class Country
    {
        public string NameCountry { get; set; }
        public long Population { get; set; }

        public Country(string name, long population)
        {
            NameCountry = name;
            Population = population;
        }
    }
}
